def send(text):
    print("发送消息... %s" % text)
